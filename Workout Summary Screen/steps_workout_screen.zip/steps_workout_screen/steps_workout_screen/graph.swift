//
//  graph.swift
//  steps_workout_screen
//
//  Created by Amos Gyamfi on 22.7.2020.
//

import Foundation
import SwiftUI

struct graph: View {
    let innerGradient = LinearGradient(gradient: Gradient(colors: [Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)), Color(#colorLiteral(red: 0, green: 0.768627451, blue: 1, alpha: 1)), Color(#colorLiteral(red: 0, green: 0, blue: 0, alpha: 1))]), startPoint: .bottom, endPoint: .topTrailing)
    var body: some View {
       
        VStack {
            
            // Top labels
            HStack(spacing: 34) {
                Text("MON")
                    .font(.caption)
                Text("TUE")
                    .font(.caption)
                Text("WED")
                    .font(.caption)
                Text("THU")
                    .font(.caption)
                Text("FRI")
                    .font(.caption)
                Text("SAT")
                    .font(.caption)
                Text("SUN")
                    .font(.caption)
            }.padding(.horizontal, 14)
            
            // Graph lines
            ZStack {  // Horizontal: 7
                HStack(alignment: .center, spacing: 58) {
                    ForEach(0 ..< 7) { item in
                        Rectangle()
                           .stroke()
                           .frame(width: 1, height: 140, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(Color(.systemGray5))
                            
                    }
                }.frame(width: 352, height: 140, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                
                VStack(spacing: 70){ // Vertical: 2
                    ForEach(0 ..< 2) { item in
                        Rectangle()
                            .stroke(style: StrokeStyle(lineWidth: 1, dash: [7, 7]))
                            .frame(width: 366, height: 1, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .foregroundColor(Color(.systemGray5))
                    }
                }
                
                Path { path in
                        path.move(to: CGPoint(x: 20, y: -30))
                        path.addLine(to: CGPoint(x: 20, y: -30))
                        path.addLine(to: CGPoint(x: 78, y: -40))
                        path.addLine(to: CGPoint(x: 138, y: -20))
                        path.addLine(to: CGPoint(x: 198, y: -40))
                        path.addLine(to: CGPoint(x: 255, y: -20))
                        path.addLine(to: CGPoint(x: 315, y: 60))
                        path.addLine(to: CGPoint(x: 375, y: 0))
                }.stroke(lineWidth: 5)
                .foregroundColor(Color(#colorLiteral(red: 0, green: 0.768627451, blue: 1, alpha: 1)))
                .rotationEffect(.degrees(180), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .rotation3DEffect(
                    .degrees(180),
                    axis: (x: 0, y: 1, z: 0.0),
                    anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .offset(x: /*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/, y: -75)
                
                
                Path { path in
                        path.move(to: CGPoint(x: 255, y: -20))
                        path.addLine(to: CGPoint(x: 255, y: -20))
                       
                        path.addLine(to: CGPoint(x: 255, y: -20))
                        path.addLine(to: CGPoint(x: 315, y: 60))
                        path.addLine(to: CGPoint(x: 375, y: 0))
                }
                .fill(innerGradient)
                .rotationEffect(.degrees(180), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .rotation3DEffect(
                    .degrees(180),
                    axis: (x: 0, y: 1, z: 0.0),
                    anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .opacity(0.2)
                .offset(x: /*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/, y: -75)
                
                
            }
            
            // Bottom labels
            HStack(alignment: .bottom) {
                Text("Day")
                    .font(.caption)
                Spacer()
                
                VStack {
                    Image(systemName: "arrow.up.circle.fill")
                        .foregroundColor(Color(.systemGreen))
                    
                    Text("WEEK")
                        .font(.caption)
                        .padding(.horizontal, /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                        .padding(.init(top: 4, leading: 10, bottom: 4, trailing: 10))
                        .background(Color(.systemGray))
                        .cornerRadius(22)
                }
                    
                
                Spacer()
                Text("Month")
                    .font(.caption)
            }.padding(.horizontal, 70)
        }
    }
}

struct graph_Previews: PreviewProvider {
    static var previews: some View {
        graph()
            
    }
}
