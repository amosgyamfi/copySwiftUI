//
//  summary.swift
//  steps_workout_screen
//
//  Created by Amos Gyamfi on 22.7.2020.
//


import Foundation
import SwiftUI

struct summary: View {
    var body: some View {
       
        HStack(alignment: .center, spacing: 30) {
            VStack {
                ZStack {
                    Circle()
                        .stroke(style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .foregroundColor(Color(.systemGray3))
                    
                    Circle()
                        .trim(from: 1/2, to: 1)
                        .stroke(style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .foregroundColor(Color(#colorLiteral(red: 0, green: 0.768627451, blue: 1, alpha: 1)))
                        .rotationEffect(.degrees(90), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    
                    Image(systemName: "flame.fill")
                        .font(.title2)
                   
                }
                
                Text("176 KCAL")
            }
            
            Spacer()
            
            VStack {
                ZStack {
                    
                    Circle()
                        .stroke(style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .foregroundColor(Color(#colorLiteral(red: 0, green: 0.768627451, blue: 1, alpha: 1)))
                        .rotationEffect(.degrees(90), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    
                    Image(systemName: "arrow.right")
                        .font(.title3)
                   
                }.overlay(Image(systemName: "star.square")
                            .font(.title3)
                            .offset(x: /*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/, y: -22.5))
                
                Text("3,7 KM")
            }
            
            Spacer()
            
            VStack {
                ZStack {

                    Circle()
                        .stroke(style: StrokeStyle(lineWidth: 4, lineCap: .round, lineJoin: .round))
                        .frame(width: 50, height: 50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                        .foregroundColor(Color(#colorLiteral(red: 0, green: 0.768627451, blue: 1, alpha: 1)))
                        .rotationEffect(.degrees(90), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    
                    Image(systemName: "clock")
                        .font(.title3)
                   
                }.overlay(Image(systemName: "star.square")
                            .font(.title3)
                            .offset(x: /*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/, y: -22.5))
                
                Text("01 : 24 H")
            }
        }.padding(.horizontal, 14)
    }
}

struct summary_Previews: PreviewProvider {
    static var previews: some View {
        summary()
            
            
            
    }
}
