//
//  progress.swift
//  steps_workout_screen
//
//  Created by Amos Gyamfi on 22.7.2020.
//

import Foundation
import SwiftUI

struct progress: View {
    var body: some View {
        ZStack {
            Circle()
                .stroke(style: StrokeStyle(lineWidth: 6, lineCap: .round, lineJoin: .round))
                .frame(width: 342, height: 342, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(Color(.systemGray3))
            
            Circle()
                .trim(from: 1/2, to: 1)
                .stroke(style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                .frame(width: 342, height: 342, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                .foregroundColor(Color(#colorLiteral(red: 0, green: 0.768627451, blue: 1, alpha: 1)))
                .rotationEffect(.degrees(90), anchor: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
            
            VStack(spacing: 8) {
                Image(systemName: "figure.walk")
                    .font(.largeTitle)
                
                Text("5250")
                    .font(.system(size: 90))
                
                Text("GOAL 10500")
            }
        }
        
    }
}

struct progress_Previews: PreviewProvider {
    static var previews: some View {
        progress()
            
            
            
    }
}
