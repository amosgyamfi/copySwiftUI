//
//  ContentView.swift
//  steps_workout_screen
//
//  Created by Amos Gyamfi on 21.7.2020.
//

import SwiftUI

struct ContentView: View {
    
    let screenFrame = Color(.systemBackground)
    var body: some View {
        // Top bar
        ZStack {
            
            screenFrame
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            VStack(spacing: 30) {
                HStack {
                    Image(systemName: "gearshape")
                    
                    Spacer()
                    
                    Text("Today")
                        .font(.title)
                       
                    Spacer()
                    
                    Image(systemName: "square.and.arrow.up")
                    
                }.padding(.horizontal, 14)
                
                progress() // Progress view
                summary() // Summary view
                graph() // Graph view
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView() // Home view
            .colorScheme(.dark)
            
    }
}
