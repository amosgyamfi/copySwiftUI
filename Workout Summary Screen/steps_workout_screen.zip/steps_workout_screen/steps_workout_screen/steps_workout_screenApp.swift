//
//  steps_workout_screenApp.swift
//  steps_workout_screen
//
//  Created by Amos Gyamfi on 21.7.2020.
//

import SwiftUI

@main
struct steps_workout_screenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            
        }
    }
}

struct steps_workout_screenApp_Previews: PreviewProvider {
    static var previews: some View {
        /*@START_MENU_TOKEN@*/Text("Hello, World!")/*@END_MENU_TOKEN@*/
    }
}
