//
//  ContentView.swift
//  Sinple Bar Graph
//
//  Created by Amos Gyamfi on 5.2.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Divider()
                .offset(y: 83)
            VStack(spacing: 20) {
                VStack(alignment: .leading, spacing: 10) {
                    Text("DELEGATES * 24 DELEGATES DECLARED")
                        .fontWeight(.bold)
                    
                    Text("1 990 delegates needed to win the nomination")
                }
                
                HStack(spacing: 20) {
                    VStack {
                        Text("10")
                        Rectangle()
                            .frame(width: 80, height: 160)
                            .foregroundColor(Color(#colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)))
                        VStack(spacing: 10){
                            Image(uiImage: #imageLiteral(resourceName: "bernie"))  // Bernie
                                .resizable()
                                .scaleEffect(1)
                                .frame(width: 60, height: 60)
                                .clipShape(Circle())
                            Text("Bernie")
                        }
                    }
                    VStack {
                        Text("10")
                        Rectangle()
                            .frame(width: 80, height: 160)
                            .foregroundColor(Color(#colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)))

                        VStack(spacing: 10){
                            Image(uiImage: #imageLiteral(resourceName: "pete"))  // Pete
                            .resizable()
                                .scaleEffect(1)
                            .frame(width: 60, height: 60)
                            .clipShape(Circle())
                            Text("Pete")
                        }
                    }
                    VStack {
                        Spacer()
                        Text("4")
                        Rectangle()
                            .frame(width: 80, height: 160/3)
                            .foregroundColor(Color(#colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)))
                        VStack(spacing: 10){
                            Image(uiImage: #imageLiteral(resourceName: "warren")) // Warren
                            .resizable()
                            .frame(width: 60, height: 60)
                            .clipShape(Circle())
                            Text("Warren")
                        }
                    }
                    VStack{
                        Spacer()
                        Text("0")
                        VStack(spacing: 10){
                            Image(uiImage: #imageLiteral(resourceName: "amy")) // Amy
                                .resizable()
                                .frame(width: 60, height: 60)
                                .clipShape(Circle())
                                Text("Amy")
                                      }
                            
                    }
                }
                
               
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
