//
//  interaction_mappingApp.swift
//  interaction_mapping
//
//  Created by Amos Gyamfi on 4.8.2020.
//

import SwiftUI

@main
struct interaction_mappingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
