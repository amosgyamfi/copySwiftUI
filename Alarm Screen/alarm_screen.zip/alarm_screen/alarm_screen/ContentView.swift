//
//  ContentView.swift
//  iPhone Alarm Screen
//
//  Created by Amos Gyamfi on 21.7.2020.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color(red: 0, green: 0, blue: 0)
                .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)

            VStack{
                
                VStack(spacing: -5){
                    Image(systemName: "lock.fill")
                        .font(.system(size: 40))
                        .foregroundColor(.white)
                    
                    Text("3.54")
                        .font(.system(size: 88))
                        .fontWeight(.thin)
                        .foregroundColor(Color(#colorLiteral(red: 0.6642242074, green: 0.6642400622, blue: 0.6642315388, alpha: 1)))
                    
                    Text("Saturday 18. July")
                        .foregroundColor(Color(#colorLiteral(red: 0.6642242074, green: 0.6642400622, blue: 0.6642315388, alpha: 1)))
                }
                
                Spacer()
                
                VStack{
                    Text("Alarm")
                        .font(.system(size: 31))
                        .foregroundColor(.white)
                    
                    Rectangle()
                        .frame(width: 198, height: 61, alignment: .center)
                        .foregroundColor(Color(#colorLiteral(red: 0.9960784314, green: 0.6235294118, blue: 0.0431372549, alpha: 1)))
                        .overlay(Text("Snooze").foregroundColor(.white))
                        .cornerRadius(30.5)
                        
                }
                
                Spacer()
                
                VStack{
                    Rectangle()
                        .frame(width: 103, height: 48, alignment: .center)
                        .foregroundColor(Color(#colorLiteral(red: 0.3490196078, green: 0.3019607843, blue: 0.2509803922, alpha: 1)))
                        .overlay(Text("Stop").foregroundColor(.white))
                        .cornerRadius(24)
                }
                
            }.padding(.all, 53)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
