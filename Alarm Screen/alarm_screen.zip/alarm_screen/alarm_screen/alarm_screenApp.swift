//
//  alarm_screenApp.swift
//  alarm_screen
//
//  Created by Amos Gyamfi on 21.7.2020.
//

import SwiftUI

@main
struct alarm_screenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
