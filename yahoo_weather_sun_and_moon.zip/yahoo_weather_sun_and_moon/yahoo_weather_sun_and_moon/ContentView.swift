//
//  ContentView.swift
//  yahoo_weather_sun_and_moon
//
//  Created by Amos Gyamfi on 10.5.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    @State private var sunMovesAlong = false
    @State private var maskedRectScalesAlong = false
    let blackPhoneScreen =  Color(#colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1))

    var body: some View {
       
        ZStack {
            blackPhoneScreen // Phone screen
                .edgesIgnoringSafeArea(.all)
            
            Text("Sun & Moon") // Label
                .font(.largeTitle)
                .foregroundColor(.white)
                .offset(y: -300)
            
             Text("5:44 AM")  // Label
                .font(.caption)
                .foregroundColor(.white)
                .offset(x: -150,y: 30)
            
            Text("20:01 PM")  // Label
                .font(.caption)
                .foregroundColor(.white)
                .offset(x: 150,y: 30)
            
            ZStack {
                
                Circle()  // Circular path: Dotted semicircle
                    .trim(from: 1/2, to: 1)
                    .stroke(style: StrokeStyle(lineWidth: 1, dash: [7, 7]))
                    .frame(width:   300, height: 300)
                    .foregroundColor(.yellow)
                
                Image(systemName: "sun.max")  // Sun symbol
                    .font(.title)
                    .foregroundColor(.yellow)
                    .offset(x: -150)
                    .rotationEffect(.degrees(90))
                    
                ZStack {
                    Rectangle() // Masked to parent
                      .frame(width:   300, height: 150)
                      .foregroundColor(.yellow)
                        .opacity(0.2)
                      .scaleEffect(x: 0.5, y: 1, anchor: .leading)
                      .offset(y: -75)
                    
                }.frame(width: 300, height: 300)
                .clipShape(Circle())  // Mask to bounds + mask to parent
                  
                Rectangle()  // X-axis
                    .frame(width: 400, height: 1)
                    .foregroundColor(.white)
                    .opacity(0.5)
                
                Circle() // Point Left
                    .frame(width: 10, height: 10)
                    .foregroundColor(.yellow)
                    .offset(x: -150)
                
                Circle() // Point Right
                    .frame(width: 10, height: 10)
                    .foregroundColor(.yellow)
                    .offset(x: 150)
            }// Inner container
            
        }
        
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
