//
//  ContentView.swift
//  popup
//
//  Created by Amos Gyamfi on 1.6.2020.
//  Copyright © 2020 Amos Gyamfi. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            Color(#colorLiteral(red: 0.7882352941, green: 0.7803921569, blue: 0.7803921569, alpha: 1))
                .edgesIgnoringSafeArea(.all)
            VStack {
                Spacer()
                
                VStack (alignment: .leading, spacing: 20) {
                    HStack {
                      Image(systemName: "pencil.circle")
                      Text("Add Project")
                    }
                    
                    Divider()
                    
                    HStack {
                      Image(systemName: "checkmark.circle")
                      Text("Add Task")
                    }
                }.frame(width: UIScreen.main.bounds.width - 60)
                 .padding()
                 .background(Color(#colorLiteral(red: 0.9568627451, green: 0.9490196078, blue: 0.9450980392, alpha: 1)))
                    .cornerRadius(16)
                
                ZStack {
                    Rectangle()
                        .frame(width: UIScreen.main.bounds.width - 30, height: UIScreen.main.bounds.height/15)
                        .foregroundColor(Color(#colorLiteral(red: 0.9568627451, green: 0.9490196078, blue: 0.9450980392, alpha: 1)))
                        .cornerRadius(16)
                    
                    Text("Done")
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
